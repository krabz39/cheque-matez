# passenger_wsgi.py — WSGI entrypoint for chapaa (Hostnali/cPanel)
import os, sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

# Force persistent state outside app folder
os.environ.setdefault("CM_STATE_DIR", "/home2/chequem1/chapaa_state")

# Optional: flush logs immediately so you see errors in stderr.log
os.environ.setdefault("PYTHONUNBUFFERED", "1")

# Import your Flask app and expose it as WSGI callable "application"
from chapaa import app as application

# Quick sanity log (shows up in stderr.log)
try:
    sys.stderr.write("[passenger] chapaa WSGI loaded; STATE_DIR="
                     + os.environ.get("CM_STATE_DIR","<unset>") + "\n")
    sys.stderr.flush()
except Exception:
    pass
